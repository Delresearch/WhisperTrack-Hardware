Date: 7/23/2025

Customer: DELRESEARCH LLC	
Customer Job Name: POPOTO WHISPERTRACK MODEM BOARD
Customer Part Number:  050-0098-00 Revision:  0

*** File Parameters List ***
 
Layers file format:  Gerber274x
     Number format:  2.5
     Zero suppression:  none
     Number units:  inch
     Coordinate system: absolute

CONTENTS OF  - 051-0098-00.ZIP

     051-0098-00_assy.art   		Gerber Fabrication Drawing 274X
     051-0098-00_place.txt
     051-0098-00assy.dxf
     051-0098-00assy.pdf
     051-0098-00assy.stp 
 
CONTENTS OF  - 052-0098-00.ZIP
    052-0098-00.L01             gerber layer 01 
    052-0098-00.L02             gerber layer 02 
    052-0098-00.L03             gerber layer 03 
    052-0098-00.L04             gerber layer 04 
    052-0098-00.L05             gerber layer 05 
    052-0098-00.L06             gerber layer 06 
    052-0098-00.L07             gerber layer 07
    052-0098-00.L08             gerber layer 08  
   
    052-0098-00.PSM             gerber layer SOLDER MASK TOP
    052-0098-00.PSP             gerber layer SOLDER PASTE TOP
    052-0098-00.PSS             gerber layer SILKSCREEN TOP
    052-0098-00.SSM             gerber layer SOLDER MASK BOTTOM
    052-0098-00.SSP             gerber layer SOLDER PASTE BOTTOM
    052-0098-00.SSS             gerber layer SILKSCREEN BOTTOM
    
    052-0098-00_1-8.ROU        gerber layer ROUTE FILE
    052-0098-00-1-8.drl       	Ncdrill file 
    052-0098-00.ipc   	        IPC356D file
    052-0098-00.tgz		ODB++ files


CONTENTS OF  - 054-0098-00.ZIP

     054-0098-00.brd   	 	Allegro Data base file


CONTENTS OF  - 057-0098-00.ZIP

     057-0098-00_fab.art   		Gerber Fabrication Drawing 274X
     057-0098-00fab.dxf 
     057-0098-00fab.pdf     
     
---->For questions call number below and reference 
Primary Contact: Evan Cornell (419-706-8315)


